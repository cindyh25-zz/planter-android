package com.practice.planter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SinglePlantActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_single_plant)
    }
}